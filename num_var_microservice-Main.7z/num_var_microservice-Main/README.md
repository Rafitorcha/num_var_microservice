Numero y variable. proyecto basico.
